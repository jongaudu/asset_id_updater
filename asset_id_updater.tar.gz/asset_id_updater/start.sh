#!/bin/bash
cppython asset_id_updater.py