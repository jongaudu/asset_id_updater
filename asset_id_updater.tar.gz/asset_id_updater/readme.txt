Application Name
================
asset_id_updater


Application Version
===================
1.0

NCOS Devices Supported
======================
ALL


External Requirements
=====================
None


Application Purpose
===================
This application will update the router asset_id with the client data


Expected Output
===============
